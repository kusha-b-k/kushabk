from distutils.core import setup

setup(name='kushabk',
      version='1.2',
      description='This is a python package just made for testing the package and versions ',
      author='KUSHA B K',
      url='https://pypi.org/project/kushabk/',
      author_email='kusha.b.k@gmail.com'
     )