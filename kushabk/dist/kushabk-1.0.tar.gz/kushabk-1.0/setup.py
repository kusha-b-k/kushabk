from distutils.core import setup

setup(name='kushabk',
      version='1.0',
      description='Python package',
      author='KUSHA B K',
      author_email='kusha.b.k@gmail.com'
     )